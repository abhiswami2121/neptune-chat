import { defineConfig } from 'tsup';

export default defineConfig({
  entry: {
    index: 'src/index.ts',
    'tools/index': 'src/tools/index.ts',
    'skills/index': 'src/skills/index.ts',
    'connectors/index': 'src/connectors/index.ts',
    'memory/index': 'src/memory/index.ts',
    'workflows/index': 'src/workflows/index.ts',
  },
  format: ['esm'],
  dts: true,
  splitting: false,
  sourcemap: true,
  clean: true,
  outDir: 'dist',
});
