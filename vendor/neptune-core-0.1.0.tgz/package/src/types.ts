import { z } from 'zod';

export interface ToolDefinition {
  name: string;
  description: string;
  category: string;
  parameters: z.ZodType<unknown>;
}

export interface Skill {
  name: string;
  description: string;
  triggers: string[];
  path: string;
}

export interface Connector {
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error';
  toolCount: number;
}

export interface WorkflowDef {
  name: string;
  description: string;
  steps: WorkflowStep[];
  triggers?: string[];
}

export interface WorkflowStep {
  name: string;
  tool: string;
  params: Record<string, unknown>;
  dependsOn?: string[];
}
