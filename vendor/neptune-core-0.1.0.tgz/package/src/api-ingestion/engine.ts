export interface IngestedApi {
  name: string;
  version: string;
  toolCount: number;
  endpoints: ApiEndpoint[];
  source: string;
  ingestedAt: Date;
}

export interface ApiEndpoint {
  method: string;
  path: string;
  description: string;
  parameters: Record<string, unknown>;
  response: string;
}

export class ApiIngestionEngine {
  async ingestFromUrl(url: string, options?: { name?: string; auth?: Record<string, string> }): Promise<IngestedApi> {
    const response = await fetch(url);
    const content = await response.text();

    let parsed: { title: string; version: string; endpoints: ApiEndpoint[] };

    if (url.endsWith('.json') || url.includes('openapi')) {
      parsed = this.parseOpenAPI(JSON.parse(content));
    } else if (url.endsWith('.md') || url.includes('readme')) {
      parsed = await this.parseMarkdownDocs(content);
    } else {
      parsed = await this.parseMarkdownDocs(content);
    }

    return {
      name: options?.name || parsed.title,
      version: parsed.version,
      toolCount: parsed.endpoints.length,
      endpoints: parsed.endpoints,
      source: url,
      ingestedAt: new Date(),
    };
  }

  private parseOpenAPI(spec: Record<string, unknown>): { title: string; version: string; endpoints: ApiEndpoint[] } {
    const info = (spec.info || {}) as Record<string, unknown>;
    const paths = (spec.paths || {}) as Record<string, Record<string, unknown>>;
    const endpoints: ApiEndpoint[] = [];

    for (const [path, methods] of Object.entries(paths)) {
      for (const [method, details] of Object.entries(methods)) {
        const d = details as Record<string, unknown>;
        endpoints.push({
          method: method.toUpperCase(),
          path,
          description: (d.summary || d.description || '') as string,
          parameters: (d.parameters || {}) as Record<string, unknown>,
          response: JSON.stringify(d.responses || {}),
        });
      }
    }

    return {
      title: (info.title || 'Unknown API') as string,
      version: (info.version || '1.0.0') as string,
      endpoints,
    };
  }

  private async parseMarkdownDocs(content: string): Promise<{ title: string; version: string; endpoints: ApiEndpoint[] }> {
    const endpoints: ApiEndpoint[] = [];
    const lines = content.split('\n');
    let title = 'Markdown API';
    let version = '1.0.0';

    for (const line of lines) {
      if (line.startsWith('# ')) title = line.replace(/^#+\s*/, '');
      const methodMatch = line.match(/\b(GET|POST|PUT|DELETE|PATCH)\b\s+(\/\S+)/i);
      if (methodMatch) {
        endpoints.push({
          method: methodMatch[1].toUpperCase(),
          path: methodMatch[2],
          description: line.replace(methodMatch[0], '').trim().replace(/^[-–—:]\s*/, ''),
          parameters: {},
          response: 'unknown',
        });
      }
    }

    return { title, version, endpoints };
  }
}

export const apiIngestionEngine = new ApiIngestionEngine();
