import type { Skill } from '../types.js';

export interface SkillManifest {
  skills: Skill[];
  loadedAt: Date;
}

export class SkillLoader {
  private skills: Map<string, Skill> = new Map();

  register(skill: Skill): void {
    this.skills.set(skill.name, skill);
  }

  find(query: string): Skill[] {
    const q = query.toLowerCase();
    return [...this.skills.values()].filter(s =>
      s.triggers.some(t => t.toLowerCase().includes(q)) ||
      s.name.toLowerCase().includes(q) ||
      s.description.toLowerCase().includes(q)
    );
  }

  getManifest(): SkillManifest {
    return {
      skills: [...this.skills.values()],
      loadedAt: new Date(),
    };
  }

  getByName(name: string): Skill | undefined {
    return this.skills.get(name);
  }
}

export const skillLoader = new SkillLoader();
