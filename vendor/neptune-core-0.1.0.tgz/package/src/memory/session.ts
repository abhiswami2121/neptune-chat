interface SessionState {
  conversationId: string;
  facts: Record<string, unknown>;
  preferences: Record<string, unknown>;
  updatedAt: Date;
}

class SessionStore {
  private store: Map<string, SessionState> = new Map();

  set(conversationId: string, state: Partial<SessionState>): void {
    const existing = this.store.get(conversationId) || {
      conversationId,
      facts: {},
      preferences: {},
      updatedAt: new Date(),
    };
    this.store.set(conversationId, { ...existing, ...state, updatedAt: new Date() });
  }

  get(conversationId: string): SessionState | undefined {
    return this.store.get(conversationId);
  }

  addFact(conversationId: string, key: string, value: unknown): void {
    const s = this.store.get(conversationId);
    if (s) {
      s.facts[key] = value;
      s.updatedAt = new Date();
    }
  }

  addPreference(conversationId: string, key: string, value: unknown): void {
    const s = this.store.get(conversationId);
    if (s) {
      s.preferences[key] = value;
      s.updatedAt = new Date();
    }
  }
}

export const sessionStore = new SessionStore();
