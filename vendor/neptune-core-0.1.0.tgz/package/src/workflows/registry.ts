import type { WorkflowDef } from '../types.js';

export interface WorkflowRun {
  id: string;
  workflowName: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  startedAt: Date;
  completedAt?: Date;
  stepResults: Record<string, unknown>;
}

class WorkflowRegistry {
  private workflows: Map<string, WorkflowDef> = new Map();
  private runs: Map<string, WorkflowRun> = new Map();

  register(workflow: WorkflowDef): void {
    this.workflows.set(workflow.name, workflow);
  }

  list(): WorkflowDef[] {
    return [...this.workflows.values()];
  }

  get(name: string): WorkflowDef | undefined {
    return this.workflows.get(name);
  }

  startRun(name: string): WorkflowRun | undefined {
    const wf = this.workflows.get(name);
    if (!wf) return undefined;
    const run: WorkflowRun = {
      id: `run_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      workflowName: name,
      status: 'running',
      startedAt: new Date(),
      stepResults: {},
    };
    this.runs.set(run.id, run);
    return run;
  }

  getRun(id: string): WorkflowRun | undefined {
    return this.runs.get(id);
  }

  completeRun(id: string, result: Record<string, unknown>): void {
    const run = this.runs.get(id);
    if (run) {
      run.status = 'completed';
      run.completedAt = new Date();
      run.stepResults = result;
    }
  }

  failRun(id: string, error: string): void {
    const run = this.runs.get(id);
    if (run) {
      run.status = 'failed';
      run.completedAt = new Date();
      run.stepResults = { error };
    }
  }
}

export const workflowRegistry = new WorkflowRegistry();
