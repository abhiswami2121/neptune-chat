import { toolDefinitions } from '../definitions.js';
import type { ToolDefinition } from '../../types.js';

export const knowledgeTools: ToolDefinition[] = [
  toolDefinitions.readSkill,
  toolDefinitions.readPRD,
  toolDefinitions.listSkills,
  toolDefinitions.searchKnowledge,
];
