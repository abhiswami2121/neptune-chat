import { toolDefinitions } from '../definitions.js';
import type { ToolDefinition } from '../../types.js';

export const workflowTools: ToolDefinition[] = [
  toolDefinitions.runWorkflow,
  toolDefinitions.scheduleWorkflow,
  toolDefinitions.listWorkflows,
];
