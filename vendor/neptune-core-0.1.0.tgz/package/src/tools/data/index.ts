import { toolDefinitions } from '../definitions.js';
import type { ToolDefinition } from '../../types.js';

export const dataTools: ToolDefinition[] = [
  toolDefinitions.queryDatabase,
  toolDefinitions.pullSlackMessages,
  toolDefinitions.fetchURL,
  toolDefinitions.googleSearch,
];
