import { z } from 'zod';
import type { ToolDefinition } from '../types.js';

// Canonical tool definitions shared across chat + v2
export const toolDefinitions: Record<string, ToolDefinition> = {
  // Knowledge
  readSkill: { name: 'readSkill', description: 'Read a skill from the cortex', category: 'knowledge', parameters: z.object({ name: z.string() }) },
  readPRD: { name: 'readPRD', description: 'Read a PRD document', category: 'knowledge', parameters: z.object({ path: z.string() }) },
  listSkills: { name: 'listSkills', description: 'List available skills', category: 'knowledge', parameters: z.object({ query: z.string().optional() }) },
  searchKnowledge: { name: 'searchKnowledge', description: 'Search the knowledge graph', category: 'knowledge', parameters: z.object({ query: z.string(), limit: z.number().optional() }) },
  // Data
  queryDatabase: { name: 'queryDatabase', description: 'Query the database', category: 'data', parameters: z.object({ sql: z.string() }) },
  pullSlackMessages: { name: 'pullSlackMessages', description: 'Pull Slack messages via VPS bridge', category: 'data', parameters: z.object({ channel: z.string(), limit: z.number().optional() }) },
  fetchURL: { name: 'fetchURL', description: 'Fetch content from a URL', category: 'data', parameters: z.object({ url: z.string() }) },
  googleSearch: { name: 'googleSearch', description: 'Search the web (placeholder)', category: 'data', parameters: z.object({ query: z.string() }) },
  // Workflow
  runWorkflow: { name: 'runWorkflow', description: 'Run a multi-step workflow', category: 'workflow', parameters: z.object({ name: z.string(), params: z.record(z.unknown()).optional() }) },
  scheduleWorkflow: { name: 'scheduleWorkflow', description: 'Schedule a workflow to run later', category: 'workflow', parameters: z.object({ name: z.string(), cron: z.string() }) },
  listWorkflows: { name: 'listWorkflows', description: 'List available workflows', category: 'workflow', parameters: z.object({}) },
  // V2 Bridge
  spawnCodingAgent: { name: 'spawnCodingAgent', description: 'Hand off to neptune-v2 coding agent', category: 'v2-bridge', parameters: z.object({ task: z.string(), repoRef: z.string().optional() }) },
  listV2Sessions: { name: 'listV2Sessions', description: 'List active V2 coding sessions', category: 'v2-bridge', parameters: z.object({}) },
  getV2Session: { name: 'getV2Session', description: 'Get details of a V2 session', category: 'v2-bridge', parameters: z.object({ sessionId: z.string() }) },
  streamV2Progress: { name: 'streamV2Progress', description: 'Stream V2 session progress', category: 'v2-bridge', parameters: z.object({ sessionId: z.string() }) },
  // Canvas
  renderArtifact: { name: 'renderArtifact', description: 'Render an artifact in the canvas', category: 'canvas', parameters: z.object({ kind: z.string(), content: z.unknown() }) },
  updateCanvas: { name: 'updateCanvas', description: 'Update an existing canvas artifact', category: 'canvas', parameters: z.object({ artifactId: z.string(), content: z.unknown() }) },
  exportCanvas: { name: 'exportCanvas', description: 'Export canvas artifact', category: 'canvas', parameters: z.object({ artifactId: z.string(), format: z.enum(['md', 'html', 'pdf']).default('md') }) },
};

export const allToolSchemas = Object.fromEntries(
  Object.entries(toolDefinitions).map(([k, v]) => [k, v.parameters])
);
