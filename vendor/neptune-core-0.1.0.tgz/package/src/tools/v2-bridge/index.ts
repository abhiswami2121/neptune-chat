import { toolDefinitions } from '../definitions.js';
import type { ToolDefinition } from '../../types.js';

export const v2BridgeTools: ToolDefinition[] = [
  toolDefinitions.spawnCodingAgent,
  toolDefinitions.listV2Sessions,
  toolDefinitions.getV2Session,
  toolDefinitions.streamV2Progress,
];
