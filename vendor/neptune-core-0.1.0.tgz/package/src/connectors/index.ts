export { connectorRegistry, type ConnectorState } from './registry.js';
