import type { Connector } from '../types.js';

export type ConnectorState = 'connected' | 'disconnected' | 'error' | 'pending';

interface ConnectorWithState extends Connector {
  configure(): Promise<void>;
  test(): Promise<boolean>;
}

class ConnectorRegistry {
  private connectors: Map<string, ConnectorWithState> = new Map();

  register(name: string, connector: ConnectorWithState): void {
    this.connectors.set(name, connector);
  }

  list(): Connector[] {
    return [...this.connectors.values()].map(({ name, type, status, toolCount }) => ({
      name, type, status, toolCount
    }));
  }

  get(name: string): ConnectorWithState | undefined {
    return this.connectors.get(name);
  }

  async testAll(): Promise<Record<string, boolean>> {
    const results: Record<string, boolean> = {};
    for (const [name, c] of this.connectors) {
      try { results[name] = await c.test(); } catch { results[name] = false; }
    }
    return results;
  }
}

export const connectorRegistry = new ConnectorRegistry();
